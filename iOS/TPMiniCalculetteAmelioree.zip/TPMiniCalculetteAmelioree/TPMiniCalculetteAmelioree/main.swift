//
//  main.swift
//  TPMiniCalculetteAmeliore
//
//  Created by valentin haveaux on 11/10/17.
//  Copyright © 2017 valentin haveaux. All rights reserved.
//

import Foundation

//Déclaration des variables
    var nombreEntre: Int //Valeur introduite par l'utlisateur
    var choixOperateur: Int
    var nbr1Calcul: Int
    var nbr2Calcul: Int
    var resultat: Int
    var continuer: Int = 1
    var nbrDeCalcul: Int = 1


//Fonction Affichant le menu de départ
    func printMenu () {
        print ("--- MENU ---")
        print ("1. Addition")
        print ("2. Soustraction")
        print ("3. Multiplication")
        print ("4. Division")
        print ("5. Modulo")
        print ("6. Carré")
        print ("")
        print ("Que voulez-vous? (De 1 à 6)")
    }

// Fonction Addition
    func Addition(nombre1: Int, nombre2: Int) -> Int {
        return nombre1 + nombre2
    }

// Fonction Soustraction
    func Soustraction(nombre1: Int, nombre2: Int) -> Int {
        return nombre1 - nombre2
    }

// Fonction Multiplication
    func Multiplication(nombre1: Int, nombre2: Int) -> Int {
        return nombre1 * nombre2
    }

// Fonction Division
    func Division(nombre1: Int, nombre2: Int) -> Int {
        return nombre1 / nombre2
    }

// Fonction Modulo
    func Modulo(nombre1: Int, nombre2: Int) -> Int {
        return nombre1 % nombre2
    }


// Fonction permettant de demander à l'utilisateur d'entrer un nombre et de le convertir en entier
    func input() -> Int {
        let strData = readLine();
    
        return Int(strData!)!
    }

// Fonction recommencer la calculette
    func repeatCalcul () {
        print("")
        print("Nombre de calcul déjà fait: " + String(nbrDeCalcul))
        print("")
        print("--- Voulez-vous recommencer? ---")
        print("1. OUI")
        print("2. NON")
        print("")
        
        continuer = input()
        
        if continuer == 1 {
            nbrDeCalcul += 1
        }
    }

// Fonction pour afficher le résultat
    func afficheResult (nombre1: Int, operateur: String, nombre2: Int, resultat: Int) {
        print(String(nombre1) + operateur + String(nombre2) + " = " + String(resultat))
    }



//DEBUT DU CODE PRINCIPAL

repeat {
    
    printMenu()
    choixOperateur = input()

//Test pour savoir si la valeur entré est comprise entre 1 et 6
    if choixOperateur >= 1 && choixOperateur <= 6 {
    
        print("")
        
        print("Veuillez introduire le premier nombre")
        nbr1Calcul = input()
        
        // L'utilisateur rentre le deuxième nombre sauf si c'est le carré qu'on demande
        if choixOperateur != 6 {
            print("Entrez le deuxième nombre : ")
            nbr2Calcul = input()
        } else {
            nbr2Calcul = nbr1Calcul
        }

    
        print("")
    
        switch choixOperateur {
        
        case 1:
            resultat = Addition(nombre1: nbr1Calcul, nombre2: nbr2Calcul)
            afficheResult(nombre1: nbr1Calcul, operateur: " + ", nombre2: nbr2Calcul, resultat: resultat)
            break
        case 2:
            resultat = Soustraction(nombre1: nbr1Calcul, nombre2: nbr2Calcul)
            afficheResult(nombre1: nbr1Calcul, operateur: " - ", nombre2: nbr2Calcul, resultat: resultat)
            break
        case 3:
            resultat = Multiplication(nombre1: nbr1Calcul, nombre2: nbr2Calcul)
            afficheResult(nombre1: nbr1Calcul, operateur: " * ", nombre2: nbr2Calcul, resultat: resultat)
            break
        case 4:
            resultat = Division(nombre1: nbr1Calcul, nombre2: nbr2Calcul)
            afficheResult(nombre1: nbr1Calcul, operateur: " / ", nombre2: nbr2Calcul, resultat: resultat)
            break
        case 5:
            resultat = Modulo(nombre1: nbr1Calcul, nombre2: nbr2Calcul)
            afficheResult(nombre1: nbr1Calcul, operateur: " % ", nombre2: nbr2Calcul, resultat: resultat)
            break
        case 6:
            resultat = Multiplication(nombre1: nbr1Calcul, nombre2: nbr2Calcul)
            print(String(nbr1Calcul) + " au carré  = " + String(resultat))
            break
        default:
            print ("ERREUR PAS D'OPERATEUR")
            break
        }
        
        repeat {
            repeatCalcul()
        }while (continuer == 0 || continuer > 2)
        
    }else {
        printMenu()
    }
    
}while (choixOperateur < 1 || choixOperateur > 6 || continuer == 1)


