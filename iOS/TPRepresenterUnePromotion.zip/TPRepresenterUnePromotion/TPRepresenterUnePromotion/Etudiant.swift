//
//  Etudiant.swift
//  TPRepresenterUnePromotion
//
//  Created by valentin haveaux on 14/10/17.
//  Copyright © 2017 valentin haveaux. All rights reserved.
//

import Foundation

//Création de la class Etudiant héritant de la class Personne
class Etudiant: Personne {
    var BOURSE: Bool                //Attribut bourse de la class Etudiant
    var ANNEEETUDE : Int            //Attribut année d'étude de la class Etudiant
    

//Constructeur de la class Etudiant
    init(nom: String, prenom: String, age: Int, bourse: Bool, annee: Int) {
        self.BOURSE = bourse
        self.ANNEEETUDE = annee
        super.init(nom: nom, prenom: prenom, age: age)
    }
    
    
//Réécriture de la fonction affiche (On rajoute l'affichage de la bourse et de l'annnée d'étude)
    override func affiche() {
        super.affiche()
        print("Bourse: " + String(self.BOURSE))
        print("Année d'étude: " + String(self.ANNEEETUDE))
    }
}
