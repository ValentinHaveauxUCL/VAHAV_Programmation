//
//  Promotion.swift
//  TPRepresenterUnePromotion
//
//  Created by valentin haveaux on 14/10/17.
//  Copyright © 2017 valentin haveaux. All rights reserved.
//

import Foundation

//Création de la class Promotion
class Promotion {
    var LISTE: [Etudiant]           //Attribut liste de la class Promotion
   
    
//Constructeur de la class Promotion
    init() {
        self.LISTE = [Etudiant]()
    }
    
    
//Fonction permettant d'ajouter un étudiant à la liste
    func ajouterEtudiant(etudiant: Etudiant) {
        self.LISTE.append(etudiant)
    }
    

//Fonction permettant de rechercher un étudiant dans la liste
    func rechercherEtudiant(nom: String, prenom: String) -> Bool {
    
        var resultatRecherche: Bool = false
        
        for etudiant in self.LISTE {
            if(etudiant.NOM == nom && etudiant.PRENOM == prenom) {
                resultatRecherche = true
            }
        }
        return resultatRecherche
    }
    

//Fonction permettant d'afficher la promotion
    func affichePromotion() {
        for etudiant in self.LISTE {                //Pour chaque étudiant dans la liste
            etudiant.affiche()                      //Afficher l'étudiant
        }
    }
    
}
