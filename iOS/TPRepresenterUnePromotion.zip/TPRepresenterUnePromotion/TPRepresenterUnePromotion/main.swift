//
//  main.swift
//  TPRepresenterUnePromotion
//
//  Created by valentin haveaux on 14/10/17.
//  Copyright © 2017 valentin haveaux. All rights reserved.
//

import Foundation


//Initialisation de la promotion
let promotion = Promotion()


//initialisation des étudiants
let etudiant1 = Etudiant(nom: "Durand", prenom: "Jacques", age: 18, bourse: true, annee: 2015)
let etudiant2 = Etudiant(nom: "Dupont", prenom: "Jean", age: 19, bourse: false, annee: 2015)
let etudiant3 = Etudiant(nom: "Duval", prenom: "Robert", age: 18, bourse: true, annee: 2015)


//Ajout des étudiants dans la promotion
promotion.ajouterEtudiant(etudiant: etudiant1)
promotion.ajouterEtudiant(etudiant: etudiant2)
promotion.ajouterEtudiant(etudiant: etudiant3)


//Recherche de Jean Dupont dans la liste de la promotion
if promotion.rechercherEtudiant(nom: "Dupont", prenom: "Jean") {
    print("Dupont Jean est bien présent dans cette promotion !")
}


//Affichage de la promotion
promotion.affichePromotion()

