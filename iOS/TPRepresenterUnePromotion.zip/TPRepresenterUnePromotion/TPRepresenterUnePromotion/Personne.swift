//
//  Personne.swift
//  TPRepresenterUnePromotion
//
//  Created by valentin haveaux on 14/10/17.
//  Copyright © 2017 valentin haveaux. All rights reserved.
//

import Foundation


//Création de la class Personne
class Personne {
    var NOM: String             //Attribut nom de la personne
    var PRENOM: String          //Attribut prenom de la personne
    var AGE: Int                //Attribut age de la personne
    
    
//Constructeur de la class Personne
    init(nom: String, prenom: String, age: Int) {
        self.NOM = nom
        self.PRENOM = prenom
        self.AGE = age
    }
    

//Fonction permettant l'affichage des informations de la personne
    func affiche() {
        print()
        print("Nom: " + self.NOM)
        print("Prénom: " + self.PRENOM)
        print("Age: " + String(self.AGE))
    }
    
}
